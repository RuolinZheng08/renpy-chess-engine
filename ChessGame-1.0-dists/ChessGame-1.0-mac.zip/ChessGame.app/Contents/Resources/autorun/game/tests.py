from chesslogic import *
from chessai import *


def to_test():
  test_random()
  # AI moves
  test_pick_move()

###############################################################################

def test_random(optional=None):
  pass

###############################################################################
# AI moves
def test_pick_move():
  chessgame = ChessGame()
  chessai = ChessAI()
  chessgame.board = \
    board_from_strings(('RN---BNR',
                        'P-P--Q--',
                        '-------K',
                        '----k--P',
                        '---pp---',
                        '--------',
                        'ppp--pp-',
                        'rnb----r'))
  chessgame.history = [Move(Loc('E', 2), Loc('E', 4), Piece('Pawn', 'White'))]
  print chessgame.in_check()
  # for move in chessgame.moves_player():
  #   print move
  # assert chessgame.checkmate()
  # print chessai.pick_move(chessgame)

###############################################################################
def main():
  to_test()

if __name__ == '__main__':
  main()